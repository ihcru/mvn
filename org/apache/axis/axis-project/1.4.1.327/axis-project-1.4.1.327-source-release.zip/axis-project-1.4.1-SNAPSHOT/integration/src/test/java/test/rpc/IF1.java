
package test.rpc;

import java.util.Calendar;

public interface IF1
{
    public String getId();

    public String getTitle();

    public String getCategory();
    
    public Calendar getDate();
}

