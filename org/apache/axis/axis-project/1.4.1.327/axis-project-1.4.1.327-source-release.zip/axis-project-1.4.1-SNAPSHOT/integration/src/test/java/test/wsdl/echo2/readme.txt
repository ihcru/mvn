This test checks various kinds of arrays (in RPC mode), including
maxOccurs="unbounded" style, SOAP arrays, and byte[]<->base64.

TODO : Check the XML coming back from the service to make sure that the
schema is right (even if we can deserialize it).
