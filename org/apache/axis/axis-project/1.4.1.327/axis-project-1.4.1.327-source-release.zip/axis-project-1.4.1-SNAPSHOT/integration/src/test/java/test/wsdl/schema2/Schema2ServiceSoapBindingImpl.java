/**
 * Schema2ServiceSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2RC2 Jan 14, 2005 (05:38:50 EST) WSDL2Java emitter.
 */

package test.wsdl.schema2;

public class Schema2ServiceSoapBindingImpl implements test.wsdl.schema2.Schema2Test{
    public java.lang.String echoLanguageTypeTest(java.lang.String languageElem) throws java.rmi.RemoteException {
        return languageElem;
    }

    public java.lang.String echoTokenTypeTest(java.lang.String tokenElem) throws java.rmi.RemoteException {
        return tokenElem;
    }

    public java.lang.String echoNameTypeTest(java.lang.String nameElem) throws java.rmi.RemoteException {
        return nameElem;
    }

    public java.lang.String echoNCNameTypeTest(java.lang.String NCNameElem) throws java.rmi.RemoteException {
        return NCNameElem;
    }

    public java.lang.String echoIDTypeTest(java.lang.String IDElem) throws java.rmi.RemoteException {
        return IDElem;
    }

    public int echoUnsignedShortTest(int unsignedShort) throws java.rmi.RemoteException {
        return unsignedShort;
    }

    public long echoUnsignedIntTest(long unsignedInt) throws java.rmi.RemoteException {
        return unsignedInt;
    }

    public short echoUnsignedByteTest(short unsignedByte) throws java.rmi.RemoteException {
        return unsignedByte;
    }

    public java.math.BigInteger echoUnsignedLongTest(java.math.BigInteger unsignedLong) throws java.rmi.RemoteException {
        return unsignedLong;
    }

    public java.math.BigInteger echoNonPositiveIntegerTest(java.math.BigInteger nonPositiveInteger) throws java.rmi.RemoteException {
        return nonPositiveInteger;
    }

    public java.math.BigInteger echoNonNegativeIntegerTest(java.math.BigInteger nonNegativeInteger) throws java.rmi.RemoteException {
        return nonNegativeInteger;
    }

    public java.math.BigInteger echoPositiveIntegerTest(java.math.BigInteger positiveInteger) throws java.rmi.RemoteException {
        return positiveInteger;
    }

    public java.math.BigInteger echoNegativeIntegerTest(java.math.BigInteger negativeInteger) throws java.rmi.RemoteException {
        return negativeInteger;
    }

    public java.util.Calendar echoTimeTest(java.util.Calendar time) throws java.rmi.RemoteException {
        return time;
    }

    public java.util.Calendar echoDateTest(java.util.Calendar date) throws java.rmi.RemoteException {
        return date;
    }

    public test.wsdl.schema2.Document echoDocument(test.wsdl.schema2.Document document) throws java.rmi.RemoteException {
        return document;
    }
}
