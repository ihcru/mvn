package test.wsdl.schema2;


public class Document {
    protected java.lang.String ID;
    protected java.lang.String _value;
    
    public Document() {
    }
    
    public Document(java.lang.String ID, java.lang.String _value) {
        this.ID = ID;
        this._value = _value;
    }
    
    public java.lang.String getID() {
        return ID;
    }
    
    public void setID(java.lang.String ID) {
        this.ID = ID;
    }
    
    public java.lang.String get_value() {
        return _value;
    }
    
    public void set_value(java.lang.String _value) {
        this._value = _value;
    }
}
