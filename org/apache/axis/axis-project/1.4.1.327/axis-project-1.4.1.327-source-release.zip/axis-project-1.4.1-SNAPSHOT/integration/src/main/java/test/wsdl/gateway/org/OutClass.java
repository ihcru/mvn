package test.wsdl.gateway.org;

public class OutClass {
	public String text;
	public int val;
}
