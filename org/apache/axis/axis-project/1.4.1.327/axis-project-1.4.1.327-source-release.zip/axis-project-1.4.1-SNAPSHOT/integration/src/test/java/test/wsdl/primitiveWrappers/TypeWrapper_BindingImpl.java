/**
 * TypeWrapper_BindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis #axisVersion# #today# WSDL2Java emitter.
 */

package test.wsdl.primitiveWrappers;

public class TypeWrapper_BindingImpl implements test.wsdl.primitiveWrappers.TypeWrapper_PortType {
    public java.lang.Integer testWrapping(java.lang.Integer testWrappingInputInteger, test.wsdl.primitiveWrappers.Bean testWrappingInputBean) throws java.rmi.RemoteException {
        return testWrappingInputInteger;
    }

}
