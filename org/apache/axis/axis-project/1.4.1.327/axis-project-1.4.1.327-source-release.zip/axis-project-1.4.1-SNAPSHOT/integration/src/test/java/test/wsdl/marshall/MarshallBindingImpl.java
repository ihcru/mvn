/**
 * MarshallBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2RC2 Feb 06, 2005 (12:14:42 EST) WSDL2Java emitter.
 */

package test.wsdl.marshall;

import java.math.BigInteger;

public class MarshallBindingImpl implements test.wsdl.marshall.MarshallPortType{
    public test.wsdl.marshall.types.MyBean[] myBeanArray(test.wsdl.marshall.types.MyBean[] arrayOfMyBean_1) throws java.rmi.RemoteException {
        return null;
    }

    public test.wsdl.marshall.types.MyBean[][] myBeanMultiArray(test.wsdl.marshall.types.MyBean[][] arrayOfarrayOfMyBean_1) throws java.rmi.RemoteException {
        return null;
    }

    public test.wsdl.marshall.types.MyBean myBean(test.wsdl.marshall.types.MyBean myBean_1) throws java.rmi.RemoteException {
        return null;
    }

    public String[] arrayOfSoapEncString(String[] parameter) throws java.rmi.RemoteException {
        return parameter;
    }

    public String[] arrayOfXsdString(String[] parameter) throws java.rmi.RemoteException {
        return parameter;
    }

    public String[][] arrayOfArrayOfSoapEncString(String[][] parameter) throws java.rmi.RemoteException {
        return parameter;
    }

    public BigInteger[][] arrayOfArrayOfinteger(BigInteger[][] parameter) throws java.rmi.RemoteException {
        return parameter;
    }

    public byte[][] arrayOfbase64Binary(byte[][] parameter) throws java.rmi.RemoteException {
        return parameter;
    }
    public byte[][] arrayOfhexBinary(byte[][] parameter) throws java.rmi.RemoteException {
        return parameter;
    }
    public byte[][] arrayOfsoapencbase64(byte[][] parameter) throws java.rmi.RemoteException {
        return parameter;
    }
    public byte[][] arrayOfbase64BinaryUnbounded(byte[][] parameter) throws java.rmi.RemoteException {
        return parameter;
    }
    public byte[][] arrayOfhexBinaryUnbounded(byte[][] parameter) throws java.rmi.RemoteException {
        return parameter;
    }
    public byte[][] arrayOfsoapencbase64Unbounded(byte[][] parameter) throws java.rmi.RemoteException {
        return parameter;
    }
}
