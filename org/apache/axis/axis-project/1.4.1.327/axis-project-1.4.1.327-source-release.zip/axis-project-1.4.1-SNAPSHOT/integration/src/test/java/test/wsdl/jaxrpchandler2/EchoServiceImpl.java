package test.wsdl.jaxrpchandler2;

public class EchoServiceImpl {

    public String echo(String echoString) {
	return echoString;
    }
    
}
