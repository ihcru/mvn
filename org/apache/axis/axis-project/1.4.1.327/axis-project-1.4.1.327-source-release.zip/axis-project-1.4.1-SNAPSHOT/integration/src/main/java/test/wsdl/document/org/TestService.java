package test.wsdl.document.org;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class TestService {
    public Document getDocument() {
        return null;
    }

    public Element getElement() {
        return null;
    }
}