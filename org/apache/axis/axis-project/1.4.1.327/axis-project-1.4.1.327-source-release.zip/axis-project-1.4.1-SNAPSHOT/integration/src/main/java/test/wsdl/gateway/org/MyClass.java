package test.wsdl.gateway.org;

/**
 * Test for Bug 14033 - bean property multi-dimensional arrays don't deserialize
 */ 
public class MyClass {
	public String[][] Values;
}
