/**
 * AnyServiceSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package test.wsdl.anytype;

public class AnyServiceSoapBindingImpl implements test.wsdl.anytype.AnyService{
    public java.lang.Object run() throws java.rmi.RemoteException {
        return new String("hello");
    }

}
