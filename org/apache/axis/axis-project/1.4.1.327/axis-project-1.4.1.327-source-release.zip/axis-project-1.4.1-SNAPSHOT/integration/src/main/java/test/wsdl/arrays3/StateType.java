package test.wsdl.arrays3;

public class StateType  implements java.io.Serializable {
    private java.lang.String state;

    public StateType() {
    }

    public StateType(
           java.lang.String state) {
           this.state = state;
    }


    /**
     * Gets the state value for this StateType.
     * 
     * @return state
     */
    public java.lang.String getState() {
        return state;
    }


    /**
     * Sets the state value for this StateType.
     * 
     * @param state
     */
    public void setState(java.lang.String state) {
        this.state = state;
    }

}
