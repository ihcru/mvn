/**
 * ArrayTest4SOAPBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jun 12, 2005 (04:49:43 EDT) WSDL2Java emitter.
 */

package test.wsdl.arrays4;

public class ArrayTest4SOAPBindingImpl implements test.wsdl.arrays4.ArrayTest4{
    public test.wsdl.arrays4.StructureType echoStruct(test.wsdl.arrays4.StructureType s) throws java.rmi.RemoteException {
        return s;
    }

}
