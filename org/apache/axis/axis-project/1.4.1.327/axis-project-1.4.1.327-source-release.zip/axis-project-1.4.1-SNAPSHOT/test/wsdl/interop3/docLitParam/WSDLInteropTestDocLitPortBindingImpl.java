/**
 * WSDLInteropTestDocLitPortBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis Wsdl2java emitter.
 */

package test.wsdl.interop3.docLitParam;

public class WSDLInteropTestDocLitPortBindingImpl implements test.wsdl.interop3.docLitParam.WSDLInteropTestDocLitPortType {
    public java.lang.String echoString(java.lang.String param0) throws java.rmi.RemoteException {
        return param0;
    }

    public test.wsdl.interop3.docLitParam.xsd.ArrayOfstring_Literal echoStringArray(test.wsdl.interop3.docLitParam.xsd.ArrayOfstring_Literal param0) throws java.rmi.RemoteException {
        return param0;
    }

    public test.wsdl.interop3.docLitParam.xsd.SOAPStruct echoStruct(test.wsdl.interop3.docLitParam.xsd.SOAPStruct param0) throws java.rmi.RemoteException {
        return param0;
    }

    public void echoVoid() throws java.rmi.RemoteException {
    }

}
