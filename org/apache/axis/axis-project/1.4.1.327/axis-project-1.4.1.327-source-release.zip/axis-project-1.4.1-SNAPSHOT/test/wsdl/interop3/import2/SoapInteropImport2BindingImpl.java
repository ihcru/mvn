/**
 * SoapInteropImport2BindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis Wsdl2java emitter.
 */

package test.wsdl.interop3.import2;

public class SoapInteropImport2BindingImpl implements test.wsdl.interop3.import2.definitions.SoapInteropImport2PortType {
    public test.wsdl.interop3.import2.xsd.SOAPStruct echoStruct(test.wsdl.interop3.import2.xsd.SOAPStruct inputStruct) throws java.rmi.RemoteException {
        return inputStruct;
    }

}
