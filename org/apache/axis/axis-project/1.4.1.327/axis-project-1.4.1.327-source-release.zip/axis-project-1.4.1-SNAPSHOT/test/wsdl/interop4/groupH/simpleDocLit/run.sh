#!/bin/sh

#
# Run the test against an endpoint
#

java test.wsdl.interop4.groupH.simpleDocLit.SimpleDocLitServiceTestCase $1

