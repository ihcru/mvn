/**
 * ShortArrayTest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2RC3 Apr 29, 2005 (10:05:23 EDT) WSDL2Java emitter.
 */
package test.wsdl.marshall3.types;

public class ShortArrayTest  implements java.io.Serializable {
    private short[] shortArray;

    public ShortArrayTest() {
    }

    public ShortArrayTest(
            short[] shortArray) {
        this.shortArray = shortArray;
    }

    /**
     * Gets the shortArray value for this ShortArrayTest.
     *
     * @return shortArray
     */
    public short[] getShortArray() {
        return shortArray;
    }

    /**
     * Sets the shortArray value for this ShortArrayTest.
     *
     * @param shortArray
     */
    public void setShortArray(short[] shortArray) {
        this.shortArray = shortArray;
    }
}
