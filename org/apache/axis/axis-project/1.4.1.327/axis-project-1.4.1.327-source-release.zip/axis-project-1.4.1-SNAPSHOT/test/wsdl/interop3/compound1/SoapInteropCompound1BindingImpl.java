/**
 * SoapInteropCompound1BindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis Wsdl2java emitter.
 */

package test.wsdl.interop3.compound1;

public class SoapInteropCompound1BindingImpl implements test.wsdl.interop3.compound1.SoapInteropCompound1PortType {
    public test.wsdl.interop3.compound1.xsd.Person echoPerson(test.wsdl.interop3.compound1.xsd.Person xPerson) throws java.rmi.RemoteException {
        return xPerson;
    }

    public test.wsdl.interop3.compound1.xsd.Document echoDocument(test.wsdl.interop3.compound1.xsd.Document xDocument) throws java.rmi.RemoteException {
        return xDocument;
    }

}
