package test.wsdl.jaxrpchandlereval;

public class UserAccountSoapBindingImpl implements test.wsdl.jaxrpchandlereval.UserAccount{
    public java.lang.String updateInfo(java.lang.String updateInfoIn0) throws java.rmi.RemoteException {
        return updateInfoIn0;
    }

}
