/**
 * StringArrayTest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2RC3 Apr 29, 2005 (10:05:23 EDT) WSDL2Java emitter.
 */
package test.wsdl.marshall3.types;

public class StringArrayTest  implements java.io.Serializable {
    private java.lang.String[] stringArray;

    public StringArrayTest() {
    }

    public StringArrayTest(
            java.lang.String[] stringArray) {
        this.stringArray = stringArray;
    }

    /**
     * Gets the stringArray value for this StringArrayTest.
     *
     * @return stringArray
     */
    public java.lang.String[] getStringArray() {
        return stringArray;
    }

    /**
     * Sets the stringArray value for this StringArrayTest.
     *
     * @param stringArray
     */
    public void setStringArray(java.lang.String[] stringArray) {
        this.stringArray = stringArray;
    }
}
