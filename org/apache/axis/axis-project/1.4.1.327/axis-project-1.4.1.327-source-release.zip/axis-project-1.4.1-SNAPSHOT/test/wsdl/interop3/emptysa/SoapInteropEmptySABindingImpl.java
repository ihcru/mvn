/**
 * SoapInteropEmptySABindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package test.wsdl.interop3.emptysa;

public class SoapInteropEmptySABindingImpl implements test.wsdl.interop3.emptysa.SoapInteropEmptySAPortType{
    public java.lang.String echoString(java.lang.String a) throws java.rmi.RemoteException {
        return a;
    }

}
