/**
 * SoapInteropCompound2BindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis Wsdl2java emitter.
 */

package test.wsdl.interop3.compound2;


public class SoapInteropCompound2BindingImpl implements test.wsdl.interop3.compound2.SoapInteropCompound2PortType {
    public test.wsdl.interop3.compound2.xsd.Employee echoEmployee(test.wsdl.interop3.compound2.xsd.Employee xEmployee) throws java.rmi.RemoteException {
        return xEmployee;
    }

}
