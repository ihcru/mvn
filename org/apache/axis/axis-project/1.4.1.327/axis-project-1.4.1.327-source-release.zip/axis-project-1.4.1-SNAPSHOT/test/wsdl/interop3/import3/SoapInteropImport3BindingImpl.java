/**
 * SoapInteropImport3BindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis Wsdl2java emitter.
 */

package test.wsdl.interop3.import3;

public class SoapInteropImport3BindingImpl implements test.wsdl.interop3.import3.SoapInteropImport3PortType {
    public test.wsdl.interop3.import3.xsd.SOAPStruct echoStruct(test.wsdl.interop3.import3.xsd.SOAPStruct inputStruct) throws java.rmi.RemoteException {
        return inputStruct;
    }

    public test.wsdl.interop3.import3.xsd.SOAPStruct[] echoStructArray(test.wsdl.interop3.import3.xsd.SOAPStruct[] inputArray) throws java.rmi.RemoteException {
        return inputArray;
    }

}
