/**
 * StringArrayTestResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2RC3 Apr 29, 2005 (10:05:23 EDT) WSDL2Java emitter.
 */
package test.wsdl.marshall3.types;

public class StringArrayTestResponse  implements java.io.Serializable {
    private java.lang.String[] stringArray;

    public StringArrayTestResponse() {
    }

    public StringArrayTestResponse(
            java.lang.String[] stringArray) {
        this.stringArray = stringArray;
    }

    /**
     * Gets the stringArray value for this StringArrayTestResponse.
     *
     * @return stringArray
     */
    public java.lang.String[] getStringArray() {
        return stringArray;
    }

    /**
     * Sets the stringArray value for this StringArrayTestResponse.
     *
     * @param stringArray
     */
    public void setStringArray(java.lang.String[] stringArray) {
        this.stringArray = stringArray;
    }
}
