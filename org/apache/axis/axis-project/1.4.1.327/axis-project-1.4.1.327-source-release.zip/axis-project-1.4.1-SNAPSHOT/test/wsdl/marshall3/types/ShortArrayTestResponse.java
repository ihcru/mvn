/**
 * ShortArrayTestResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2RC3 Apr 29, 2005 (10:05:23 EDT) WSDL2Java emitter.
 */
package test.wsdl.marshall3.types;

public class ShortArrayTestResponse  implements java.io.Serializable {
    private short[] shortArray;

    public ShortArrayTestResponse() {
    }

    public ShortArrayTestResponse(
            short[] shortArray) {
        this.shortArray = shortArray;
    }

    /**
     * Gets the shortArray value for this ShortArrayTestResponse.
     *
     * @return shortArray
     */
    public short[] getShortArray() {
        return shortArray;
    }

    /**
     * Sets the shortArray value for this ShortArrayTestResponse.
     *
     * @param shortArray
     */
    public void setShortArray(short[] shortArray) {
        this.shortArray = shortArray;
    }
}
